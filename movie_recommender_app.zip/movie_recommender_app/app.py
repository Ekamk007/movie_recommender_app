import streamlit as st
import numpy as np
import pandas as pd
import pickle
import requests
import os
from pathlib import Path

# ── Page Config ───────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="CineMatch — Movie Recommender",
    page_icon="🎬",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ── Custom CSS ────────────────────────────────────────────────────────────────
st.markdown("""
<style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap');

    html, body, [class*="css"] { font-family: 'Inter', sans-serif; }

    .hero {
        background: linear-gradient(135deg, #0f0c29, #302b63, #24243e);
        border-radius: 16px; padding: 2.5rem 2rem;
        text-align: center; margin-bottom: 2rem;
    }
    .hero h1 { color: #fff; font-size: 2.4rem; font-weight: 700; margin: 0; }
    .hero p  { color: #a0aec0; font-size: 1rem; margin-top: 0.5rem; }

    .movie-card {
        background: #1a1a2e;
        border: 1px solid #2d2d44;
        border-radius: 14px;
        overflow: hidden;
        transition: transform 0.2s, box-shadow 0.2s;
        height: 100%;
    }
    .movie-card:hover {
        transform: translateY(-4px);
        box-shadow: 0 12px 32px rgba(99,179,237,0.18);
    }
    .movie-card img { width: 100%; border-radius: 14px 14px 0 0; }
    .card-body { padding: 0.8rem 1rem 1rem; }
    .card-title { color: #e2e8f0; font-weight: 700; font-size: 0.95rem; margin-bottom: 0.4rem; }
    .badge {
        display: inline-block; border-radius: 20px;
        padding: 2px 10px; font-size: 0.72rem; font-weight: 600;
        margin-right: 4px; margin-bottom: 4px;
    }
    .badge-sim  { background: #2b4a7a; color: #90cdf4; }
    .badge-sent { background: #2a4a3e; color: #68d391; }
    .badge-score{ background: #4a3520; color: #f6ad55; }
    .sentiment-bar-wrap { background: #2d2d44; border-radius: 8px; height: 6px; margin-top: 6px; }
    .sentiment-bar { height: 6px; border-radius: 8px; background: linear-gradient(90deg,#48bb78,#68d391); }

    .section-title {
        font-size: 1.2rem; font-weight: 700; color: #90cdf4;
        border-left: 4px solid #63b3ed; padding-left: 0.75rem;
        margin-bottom: 1.2rem;
    }
    .info-box {
        background: #16213e; border: 1px solid #0f3460;
        border-radius: 10px; padding: 1rem 1.2rem; margin-bottom: 1rem;
        color: #a0aec0; font-size: 0.88rem; line-height: 1.6;
    }
    div[data-testid="stSelectbox"] label { color: #90cdf4 !important; font-weight: 600; }
    div[data-testid="stButton"] button {
        background: linear-gradient(135deg, #2b5797, #1a3a6b);
        color: white; border: none; border-radius: 10px;
        padding: 0.6rem 2rem; font-weight: 700; font-size: 1rem;
        width: 100%; transition: opacity 0.2s;
    }
    div[data-testid="stButton"] button:hover { opacity: 0.85; }
</style>
""", unsafe_allow_html=True)

# ── TMDB Config ───────────────────────────────────────────────────────────────
TMDB_API_KEY = os.getenv("TMDB_API_KEY", "3603eefeb8b7765dce0f2938bd9b250a")
POSTER_BASE  = "https://image.tmdb.org/t/p/w500"
FALLBACK_IMG = "https://via.placeholder.com/300x450/1a1a2e/90cdf4?text=No+Poster"


# ── Data Loading ──────────────────────────────────────────────────────────────
@st.cache_resource(show_spinner=False)
def load_artifacts():
    """Load pre-built pickle artifacts (movies.pkl + similarity.pkl)."""
    movies_path     = Path("movies.pkl")
    similarity_path = Path("similarity.pkl")

    if not movies_path.exists() or not similarity_path.exists():
        return None, None

    movies_df  = pickle.load(open(movies_path, "rb"))
    similarity = pickle.load(open(similarity_path, "rb"))
    return movies_df, similarity


@st.cache_data(ttl=3600, show_spinner=False)
def fetch_poster(movie_id: int) -> str:
    try:
        url  = f"https://api.themoviedb.org/3/movie/{movie_id}?api_key={TMDB_API_KEY}&language=en-US"
        data = requests.get(url, timeout=5).json()
        path = data.get("poster_path")
        return POSTER_BASE + path if path else FALLBACK_IMG
    except Exception:
        return FALLBACK_IMG


@st.cache_data(ttl=3600, show_spinner=False)
def fetch_reviews(movie_id: int) -> list:
    try:
        url  = f"https://api.themoviedb.org/3/movie/{movie_id}/reviews?api_key={TMDB_API_KEY}&language=en-US"
        data = requests.get(url, timeout=5).json()
        return [r["content"] for r in data.get("results", [])]
    except Exception:
        return []


@st.cache_data(ttl=3600, show_spinner=False)
def fetch_movie_details(movie_id: int) -> dict:
    try:
        url  = f"https://api.themoviedb.org/3/movie/{movie_id}?api_key={TMDB_API_KEY}&language=en-US"
        data = requests.get(url, timeout=5).json()
        return {
            "overview":    data.get("overview", ""),
            "vote_avg":    data.get("vote_average", 0),
            "vote_count":  data.get("vote_count", 0),
            "release":     data.get("release_date", "")[:4],
            "runtime":     data.get("runtime", 0),
            "genres":      [g["name"] for g in data.get("genres", [])],
            "tagline":     data.get("tagline", ""),
        }
    except Exception:
        return {}


# ── Lightweight Sentiment (no HuggingFace needed) ────────────────────────────
def simple_sentiment(reviews: list) -> float:
    """
    Keyword-based sentiment scorer — runs without PyTorch / HuggingFace.
    Returns a float in [0, 1] where 1 = fully positive.
    For the full transformer-based pipeline see Movie.ipynb.
    """
    if not reviews:
        return 0.5   # neutral when no reviews

    pos_words = {
        "amazing", "great", "excellent", "fantastic", "love", "loved", "wonderful",
        "brilliant", "masterpiece", "outstanding", "perfect", "best", "beautiful",
        "enjoy", "enjoyed", "incredible", "superb", "awesome", "good", "fun",
        "entertaining", "thrilling", "captivating", "stunning", "magnificent",
        "heartfelt", "moving", "emotional", "compelling", "powerful",
    }
    neg_words = {
        "bad", "worst", "terrible", "awful", "boring", "disappointing", "hate",
        "poor", "mediocre", "waste", "horrible", "dull", "stupid", "slow",
        "weak", "annoying", "forgettable", "overrated", "mess", "disaster",
        "confusing", "pointless", "painful", "tedious", "shallow",
    }

    scores = []
    for review in reviews[:8]:   # limit to 8 reviews for speed
        words = review.lower().split()
        pos = sum(1 for w in words if w in pos_words)
        neg = sum(1 for w in words if w in neg_words)
        total = pos + neg
        scores.append(pos / total if total else 0.5)

    return round(sum(scores) / len(scores), 3)


# ── Recommendation Engine ─────────────────────────────────────────────────────
def recommend(movie_title: str, movies_df, similarity, n_candidates: int = 10, top_n: int = 5):
    idx       = movies_df[movies_df["title"] == movie_title].index[0]
    distances = similarity[idx]
    candidates = sorted(enumerate(distances), key=lambda x: x[1], reverse=True)[1: n_candidates + 1]

    results = []
    prog = st.progress(0, text="Fetching recommendations…")

    for step, (i, sim_score) in enumerate(candidates):
        prog.progress((step + 1) / len(candidates), text=f"Analysing movie {step+1}/{len(candidates)}…")

        row      = movies_df.iloc[i]
        movie_id = int(row["movie_id"])
        title    = row["title"]

        poster   = fetch_poster(movie_id)
        details  = fetch_movie_details(movie_id)
        reviews  = fetch_reviews(movie_id)
        sentiment = simple_sentiment(reviews)

        # Hybrid score: 80% content similarity + 20% sentiment
        final_score = round(0.8 * sim_score + 0.2 * sentiment, 4)

        results.append({
            "title":       title,
            "movie_id":    movie_id,
            "poster":      poster,
            "similarity":  round(float(sim_score), 4),
            "sentiment":   sentiment,
            "final_score": final_score,
            "details":     details,
            "n_reviews":   len(reviews),
        })

    prog.empty()
    results.sort(key=lambda x: x["final_score"], reverse=True)
    return results[:top_n]


# ── Sidebar ───────────────────────────────────────────────────────────────────
with st.sidebar:
    st.markdown("## ⚙️ Settings")
    top_n       = st.slider("Number of recommendations", 3, 10, 5)
    show_detail = st.toggle("Show movie details", value=True)
    show_scores = st.toggle("Show scoring breakdown", value=True)
    st.markdown("---")
    st.markdown("### How it works")
    st.markdown(
        "1. **Content-based filtering** — tags are built from plot, genres, keywords, top-3 cast, director, then stemmed and vectorised with Bag-of-Words (5 000 features).\n\n"
        "2. **Cosine similarity** — pairwise similarity matrix across all 4 800+ movies.\n\n"
        "3. **Hybrid scoring** — final rank = 80% similarity + 20% sentiment (keyword-based; "
        "full HuggingFace BERT pipeline is in the notebook).\n\n"
        "4. **TMDB API** — live posters, overviews, ratings, runtimes."
    )
    st.markdown("---")
    st.caption("Data: TMDB 5000 Movies Dataset")


# ── Hero ──────────────────────────────────────────────────────────────────────
st.markdown("""
<div class="hero">
    <h1>🎬 CineMatch</h1>
    <p>Content-based + Sentiment-aware Movie Recommendation Engine</p>
</div>
""", unsafe_allow_html=True)

# ── Load Artifacts ────────────────────────────────────────────────────────────
movies_df, similarity = load_artifacts()

if movies_df is None:
    st.error(
        "**Pickle files not found.**\n\n"
        "Run `Movie.ipynb` first to generate `movies.pkl` and `similarity.pkl`, "
        "then place them in the same folder as `app.py`."
    )
    st.info(
        "Quick fix:\n"
        "```bash\n"
        "jupyter nbconvert --to notebook --execute Movie.ipynb\n"
        "```\n"
        "This will produce both `.pkl` files automatically."
    )
    st.stop()

movie_list = sorted(movies_df["title"].values)

# ── Search Bar ────────────────────────────────────────────────────────────────
col_sel, col_btn = st.columns([4, 1])

with col_sel:
    selected_movie = st.selectbox(
        "Search for a movie you like",
        movie_list,
        index=movie_list.index("Avatar") if "Avatar" in movie_list else 0,
        placeholder="Type to search…",
    )

with col_btn:
    st.markdown("<div style='margin-top:28px'>", unsafe_allow_html=True)
    clicked = st.button("🔍  Recommend")
    st.markdown("</div>", unsafe_allow_html=True)

# ── Show selected movie card ──────────────────────────────────────────────────
if selected_movie:
    sel_row    = movies_df[movies_df["title"] == selected_movie].iloc[0]
    sel_id     = int(sel_row["movie_id"])
    sel_poster = fetch_poster(sel_id)
    sel_detail = fetch_movie_details(sel_id)

    st.markdown('<div class="section-title">Selected Movie</div>', unsafe_allow_html=True)

    c1, c2 = st.columns([1, 4])
    with c1:
        st.image(sel_poster, width=160)
    with c2:
        st.markdown(f"### {selected_movie}")
        if sel_detail:
            genres_str = " · ".join(sel_detail.get("genres", []))
            st.caption(f"{sel_detail.get('release', '')}  ·  {sel_detail.get('runtime', '')} min  ·  {genres_str}")
            if sel_detail.get("tagline"):
                st.markdown(f"*\"{sel_detail['tagline']}\"*")
            if sel_detail.get("overview"):
                st.markdown(sel_detail["overview"])
            rating = sel_detail.get("vote_avg", 0)
            st.markdown(f"⭐ **{rating}/10** ({sel_detail.get('vote_count', 0):,} votes)")

    st.markdown("---")


# ── Recommendations ───────────────────────────────────────────────────────────
if clicked:
    st.markdown(f'<div class="section-title">Top {top_n} Recommendations for &nbsp;<em>{selected_movie}</em></div>',
                unsafe_allow_html=True)

    with st.spinner("Building recommendations…"):
        results = recommend(selected_movie, movies_df, similarity, n_candidates=max(top_n * 2, 10), top_n=top_n)

    if not results:
        st.warning("No recommendations found. Try a different movie.")
    else:
        cols = st.columns(min(top_n, 5))

        for idx, (col, movie) in enumerate(zip(cols, results)):
            with col:
                details  = movie["details"]
                genres   = " · ".join(details.get("genres", [])[:2]) if details else ""
                rating   = details.get("vote_avg", "—") if details else "—"
                release  = details.get("release", "") if details else ""
                sent_pct = int(movie["sentiment"] * 100)

                st.markdown(f"""
<div class="movie-card">
    <img src="{movie['poster']}" alt="{movie['title']}" onerror="this.src='{FALLBACK_IMG}'"/>
    <div class="card-body">
        <div class="card-title">{idx+1}. {movie['title']}</div>
        <div style="color:#718096; font-size:0.78rem; margin-bottom:6px">
            {release}{"  ·  " if release else ""}{genres}{"  ·  ⭐ "+str(rating) if rating else ""}
        </div>
""", unsafe_allow_html=True)

                if show_scores:
                    st.markdown(f"""
        <span class="badge badge-sim">Sim {movie['similarity']:.2f}</span>
        <span class="badge badge-sent">Mood {sent_pct}%</span>
        <span class="badge badge-score">Score {movie['final_score']:.3f}</span>
        <div style="margin-top:6px; color:#718096; font-size:0.72rem">{movie['n_reviews']} reviews analysed</div>
        <div class="sentiment-bar-wrap">
            <div class="sentiment-bar" style="width:{sent_pct}%"></div>
        </div>
""", unsafe_allow_html=True)

                st.markdown("</div></div>", unsafe_allow_html=True)

        # ── If top_n > 5, show second row ─────────────────────────────────
        if top_n > 5 and len(results) > 5:
            st.markdown("<br>", unsafe_allow_html=True)
            cols2 = st.columns(min(top_n - 5, 5))
            for idx2, (col, movie) in enumerate(zip(cols2, results[5:])):
                with col:
                    details  = movie["details"]
                    genres   = " · ".join(details.get("genres", [])[:2]) if details else ""
                    rating   = details.get("vote_avg", "—") if details else "—"
                    release  = details.get("release", "") if details else ""
                    sent_pct = int(movie["sentiment"] * 100)

                    st.markdown(f"""
<div class="movie-card">
    <img src="{movie['poster']}" alt="{movie['title']}" onerror="this.src='{FALLBACK_IMG}'"/>
    <div class="card-body">
        <div class="card-title">{idx2+6}. {movie['title']}</div>
        <div style="color:#718096; font-size:0.78rem; margin-bottom:6px">
            {release}{"  ·  " if release else ""}{genres}{"  ·  ⭐ "+str(rating) if rating else ""}
        </div>
""", unsafe_allow_html=True)

                    if show_scores:
                        st.markdown(f"""
        <span class="badge badge-sim">Sim {movie['similarity']:.2f}</span>
        <span class="badge badge-sent">Mood {sent_pct}%</span>
        <span class="badge badge-score">Score {movie['final_score']:.3f}</span>
        <div class="sentiment-bar-wrap">
            <div class="sentiment-bar" style="width:{sent_pct}%"></div>
        </div>
""", unsafe_allow_html=True)

                    st.markdown("</div></div>", unsafe_allow_html=True)

        # ── Score comparison table ─────────────────────────────────────────
        st.markdown("<br>", unsafe_allow_html=True)
        st.markdown('<div class="section-title">Scoring Breakdown</div>', unsafe_allow_html=True)

        df_results = pd.DataFrame([{
            "Rank":           i + 1,
            "Title":          m["title"],
            "Similarity":     m["similarity"],
            "Sentiment":      m["sentiment"],
            "Final Score":    m["final_score"],
            "Reviews Used":   m["n_reviews"],
            "TMDB Rating":    m["details"].get("vote_avg", "—") if m["details"] else "—",
        } for i, m in enumerate(results)])

        def color_score(val):
            try:
                v = float(val)
                if v >= 0.7: return "color: #68d391"
                if v >= 0.4: return "color: #f6ad55"
                return "color: #fc8181"
            except Exception:
                return ""

        styled = df_results.style.applymap(color_score, subset=["Similarity", "Sentiment", "Final Score"])
        st.dataframe(styled, use_container_width=True, hide_index=True)

        csv = df_results.to_csv(index=False).encode("utf-8")
        st.download_button("⬇️ Download Results CSV", csv, "recommendations.csv", "text/csv")

# ── Footer ────────────────────────────────────────────────────────────────────
st.markdown("---")
st.caption(
    "Data: TMDB 5000 Movies Dataset · Posters & metadata: The Movie Database API · "
    "Similarity: Cosine (Bag-of-Words, 5 000 features) · "
    "Sentiment: keyword-based (notebook uses HuggingFace DistilBERT) · "
    "Full pipeline in Movie.ipynb"
)
